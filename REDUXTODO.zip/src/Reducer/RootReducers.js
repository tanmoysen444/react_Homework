import ToDoReducers from './ToDoReducers';
import { combineReducers } from 'redux';
const RootReducers=combineReducers({
    ToDoReducers,
   
})
export default RootReducers;