import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { addTodo, deleteTodo, removeTodo } from '../Actions/AddTodo'
export const Todo = () => {
    const [inputData, setinputData] = useState('')
    console.log("input data",inputData);
    const list = useSelector((state) => state.ToDoReducers.list)
    const dispatch = useDispatch()
    return (
        <div>
            <figure>
                <figcaption>Add Your List Here 📃</figcaption>
            </figure>

            <div>
                <input type="text" placeholder='🖋️Add Items' value={inputData}
                    onChange={(event) => setinputData(event.target.value)} />
                    
                <button 
                 onClick={() => dispatch(addTodo(inputData), setinputData(''))}>
                     ➕Add
                     </button>
            </div>
            <div className='showItems'>
                {list.map((elem)=>{
                     return(
                        <div className='eachItems' key={elem.id}>
                        <h3>{elem.data}</h3>
                        <button  title='Delete Item' onClick={() => dispatch(deleteTodo(elem.id), setinputData(''))}>✂️</button>
    
                    </div>
                     )
                })}
               
            </div>


        </div>
    )
}
