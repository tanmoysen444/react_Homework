import React, { useState } from 'react'



function ComponentA() {
    const [inputlist, setinputlist] = useState("")
    const [items, setitems] = useState([])
const itemEvent=(event)=>{
    setinputlist(event.target.value)
}
const listOfItems=()=>{
    setitems((oldItem)=>{
        return [...oldItem,inputlist]
    })
    setinputlist('')
    // const removeThis=()=>
}
  return (
    <div>
        <h1>To Do List</h1>
        <input type="text" placeholder='Enter Items'
        value={inputlist}
        onChange={itemEvent} />
        <button onClick={listOfItems}>+</button>
       <ol> <li>
        {items.map( (itemval,idx)=>{
            return <h3 id={idx}> {itemval} <button >x</button> </h3>
        } )}
        </li></ol>
  
      
    </div>
  )
}

export default ComponentA;