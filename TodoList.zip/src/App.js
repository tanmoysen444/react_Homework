import './App.css';
import ComponentA from './Components/ComponentA';

function App() {
  return (
    <div className="App">

    
   <ComponentA/>
  
    </div>
  );
}

export default App;
