import React, { useState } from 'react'
import RecipeDescription from './RecipeDescription'
import RecipeList from './RecipeList'
import './RecipeParent.css'
import RecipeTitle from './RecipeTitle';


function RecipeParent() {

  const [Item, setItem] = useState({
    gulab: "Gulab",
    rasgulla: "Rasagulla",
    paneer: "Paneer"

  })

  let getGulab = (data) => {
    console.log("Gulab jamun >>", data)
    setItem({
      gulab: data,
      rasgulla: "Rasagulla",
      paneer: "Paneer"
    })
  }

  let getRasagulla = (data) => {
    console.log("Rasagulla >>", data)
    setItem({
      gulab: "Gulab",
      rasgulla: data,
      paneer: "Paneer"
    })
  }
  let getPaneer = (data) => {
    console.log("Paneer>>", data)
    setItem({
      gulab: "Gulab",
      rasgulla: "Rasagulla",
      paneer: data
    })
  }

  return (
    <div>
      <RecipeTitle />
      <div className='RecipeParent_Child'>
        <RecipeList getGulab={getGulab} getRasagulla={getRasagulla} getPaneer={getPaneer} />
        <RecipeDescription descGulab={Item.gulab} descRasgulla={Item.rasgulla} descPaneer={Item.paneer} />
      </div>
    </div>
  )
}

export default RecipeParent