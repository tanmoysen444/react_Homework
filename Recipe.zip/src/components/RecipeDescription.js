import React, { useState } from 'react'
import './RecipeDescription.css'

function RecipeDescription(props) {

    // console.log("Props in RecipeDescription >>", props)

    return (
        <div>
            <div className="RecipeDescription__Parent" >
                <div className={props.descGulab}>
                    <h2> Gulab Jamun</h2>
                    <img src="https://cdn.pixabay.com/photo/2014/06/18/15/48/indian-sweet-371357_960_720.jpg" alt='none' />
                    <h4>Steps in making Gulab Jamun</h4>
                    <p>First of all, let’s prepare Sugar syrup for Gulab jamuns. Take a big wide Pan and add sugar into it. Now add 2 cups of...
                        Now add saffron strands and cardamom powder to the syrup and stir. Keep this syrup aside.
                        Now take khoya/Dried evaporated milk in a bowl and mash it very well so that there should be no lumps. Add all purpose...
                        Add milk and gather together to form a soft dough. Don’t knead much, just gently mix and gather.
                        Now divide the dough into equal parts, I got 15 from my dough.</p>
                </div>
                <div className={props.descRasgulla}>
                    <h2>Rasagulla</h2>
                    <img src="https://media.istockphoto.com/photos/rasagulla-diwali-sweets-selective-focus-picture-id618455602?s=612x612" alt='none' />
                    <h4>Steps in making Rasagulla</h4>
                    <p>Crush 1.5 inches ginger and 6 to 7 small to medium sized garlic to a fine paste in a mortar-pestle. You will need 1 tablespoon of crushed ginger-garlic or 1 tablespoon of ready ginger-garlic paste.Don’t knead much, just gently mix and gather.
                        Now divide the dough into equal parts, I got 15 from my dough. Keep this syrup aside.
                        Now take khoya/Dried evaporated milk in a bowl and mash it very well so that there should be no lumps. Add all purpose...
                        Add milk and gather together to form a soft dough.</p>
                </div>
                <div className={props.descPaneer}>
                    <h2>Paneer Tikka</h2>
                    <img src="https://media.istockphoto.com/photos/paneer-tikka-at-skewers-in-black-bowl-at-dark-slate-background-paneer-picture-id1186759790?b=1&k=20&m=1186759790&s=170667a&w=0&h=8A1h7qK3eCZU1DXlRS55bjZxFFtlboZlXZJa-uOi3Lg=" alt='none' /> 
                    <h4>Steps in making Paneer Tikka</h4>
                    <p>Peel, rinse and dice 1 medium-sized onion in square shaped 1 to 1.5 inches pieces. Rinse and slice 1 small to medium sized capsicum (green bell pepper) in 1 to 1.5 inches pieces. You will need ½ cup each of onions and capsicum. Keep aside. You can also use tomatoes if you want. Don’t knead much, just gently mix and gather.
                        Now divide the dough into equal parts, I got 15 from my dough. Crush 1.5 inches ginger and 6 to 7 small to medium sized garlic to a fine paste in a mortar-pestle. You will need 1 tablespoon of crushed ginger-garlic or 1 tablespoon of ready ginger-garlic paste.</p>
                </div>
            </div>
        </div>
    )
}

export default RecipeDescription