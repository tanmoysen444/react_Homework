import React from 'react'
import './RecipeTitle.css'

function RecipeTitle() {
  return (
    <div className='RecipeTitle'>  
        <h2> SLV Recipe book</h2>
    </div>
  )
}

export default RecipeTitle