import React from 'react'
import './RecipeList.css'

function RecipeList(props) {
  // console.log("Props in RecipeList >>",props)
  return (
    <div className="RecipeList__Parent">
        <div className="RecipeList__Child"  onClick={()=>props.getGulab("none")}>
            <h4>1</h4>
            <h4>Gulab jamun</h4>
            <img src="https://cdn.pixabay.com/photo/2014/06/18/15/48/indian-sweet-371357_960_720.jpg" alt='none'/>
        </div>
        <div className="RecipeList__Child"  onClick={()=>props.getRasagulla("none")}>
            <h4>2</h4>
            <h4>Rasagulla</h4>
            <img src="https://media.istockphoto.com/photos/rasagulla-diwali-sweets-selective-focus-picture-id618455602?s=612x612" alt='none'/>
        </div>
        <div className="RecipeList__Child"  onClick={()=>props.getPaneer("none")}>
            <h4>3</h4>
            <h4>Paneer Tika</h4>
            <img src="https://media.istockphoto.com/photos/paneer-tikka-at-skewers-in-black-bowl-at-dark-slate-background-paneer-picture-id1186759790?b=1&k=20&m=1186759790&s=170667a&w=0&h=8A1h7qK3eCZU1DXlRS55bjZxFFtlboZlXZJa-uOi3Lg=" alt='none'/>
        </div>
    </div>
  )
} 

export default RecipeList