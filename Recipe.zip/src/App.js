import logo from './logo.svg';
import './App.css';
import RecipeParent from './components/RecipeParent';

function App() {
  return (
    <div className="App">
     < RecipeParent/>
    </div>
  );
}

export default App;
